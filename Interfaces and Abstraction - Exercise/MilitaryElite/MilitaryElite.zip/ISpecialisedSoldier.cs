﻿namespace MilitaryElite
{
    public interface ISpecialisedSoldier
    {
        public string Corps { get; set; }
    }
}