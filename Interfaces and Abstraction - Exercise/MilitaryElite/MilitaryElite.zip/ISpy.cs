﻿namespace MilitaryElite
{
    public interface ISpy
    {
        public int CodeNumber { get; set; }
    }
}