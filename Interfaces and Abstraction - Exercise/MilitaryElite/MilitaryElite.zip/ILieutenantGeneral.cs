﻿using System.Collections.Generic;

namespace MilitaryElite
{
    public interface ILieutenantGeneral
    {
        public List<Private> Privates { get; set; }
    }
}