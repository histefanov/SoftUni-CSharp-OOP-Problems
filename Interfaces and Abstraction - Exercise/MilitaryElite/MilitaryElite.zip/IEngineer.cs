﻿using System.Collections.Generic;

namespace MilitaryElite
{
    public interface IEngineer
    {
        public List<Repair> Repairs { get; set; }
    }
}