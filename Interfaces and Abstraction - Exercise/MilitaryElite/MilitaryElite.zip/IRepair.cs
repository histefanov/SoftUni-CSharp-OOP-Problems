﻿namespace MilitaryElite
{
    public interface IRepair
    {
        public string PartName { get; set; }
        public int WorkHours { get; set; }
    }
}