﻿using NUnit.Framework;
using System;

[TestFixture]
public class DummyTests
{
    [Test]
    public void DummyLosesHealthIfAttacked()
    {
        Axe axe = new Axe(50, 20);
        Dummy dummy = new Dummy(100, 0);

        axe.Attack(dummy);

        Assert.That(dummy.Health == 50);
    }

    [Test]
    public void DeadDummyThrowsExceptionIfAttacked()
    {
        Axe axe = new Axe(50, 20);
        Dummy dummy = new Dummy(0, 0);

        Assert.Throws<InvalidOperationException>(() => axe.Attack(dummy));
    }

    [Test]
    public void DeadDummyCanGiveExp()
    {
        Dummy dummy = new Dummy(0, 100);

        int exp = dummy.GiveExperience();

        Assert.That(exp == 100);
    }

    [Test]
    public void AliveDummyCannotGiveExp()
    {
        Dummy dummy = new Dummy(100, 100);

        Assert.Throws<InvalidOperationException>(() => dummy.GiveExperience());
    }
}
