﻿namespace CommandPattern.IOManagement.Contracts
{
    public interface IReader
    {
        public string ReadLine();
    }
}
