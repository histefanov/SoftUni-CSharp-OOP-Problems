﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

using CommandPattern.Core.Contracts;

namespace CommandPattern.Core.Models
{
    public class CommandInterpreter : ICommandInterpreter
    {
        private const string COMMANDS_NAMESPACE = "CommandPattern.Core.Models.";

        public string Read(string args)
        {
            string[] argsArr = args.Split(' ', 
                StringSplitOptions.RemoveEmptyEntries);

            string commandName = COMMANDS_NAMESPACE + argsArr[0] + "Command";
            string[] commandArgs = argsArr[1].Split(' ', 
                StringSplitOptions.RemoveEmptyEntries);

            var cmdType = Type.GetType(commandName);
            ICommand cmdInstance = Activator.CreateInstance(cmdType) as ICommand;

            return cmdInstance.Execute(commandArgs);
        }
    }
}
