﻿using System;

namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var fish = new Fish("sharan", 10, 30);
            Console.WriteLine(fish.Grams);
        }
    }
}