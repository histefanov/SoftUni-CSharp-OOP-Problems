﻿using System;

namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //var bear = new Bear("Pesho");
            //Console.WriteLine(bear.Name);

            //var snake = new Snake("Gosho");
            //Console.WriteLine(snake.Name);

            //var gorilla = new Gorilla("Tisho");
            //Console.WriteLine(gorilla.Name);

            //var reptile = new Reptile("Aivar");
            //Console.WriteLine(reptile.Name);
        }
    }
}