﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class SportCar : Car
    {
        public SportCar(int horsePower, double fuel)
            : base(horsePower, fuel)
        {
            this.DefaultFuelConsumption = 10;
        }

        public override double FuelConsumption { get => this.DefaultFuelConsumption; }

        public override void Drive(double kilometers)
        {
            double fuelRequired = (FuelConsumption * kilometers) / 100;
            Fuel = Fuel >= fuelRequired ? Fuel - fuelRequired : 0;
        }
    }
}
